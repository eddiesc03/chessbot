import cv2
import os
import pickle

# Create a folder to store labeled images
output_dir = "labeled_pieces"
os.makedirs(output_dir, exist_ok=True)

# List of piece square images you want to label (e.g. from 64 squares)
# Replace this with your actual list of square images:
with open("squares.pkl", "rb") as file:
   square_images = pickle.load(file)

# Dictionary to store labels
# Try to load existing labels
labels = {}
if os.path.exists("piece_labels.pkl"):
    with open("piece_labels.pkl", "rb") as f:
        labels = pickle.load(f)

print("Label keys: p=pawn, n=knight, b=bishop, r=rook, q=queen, k=king, e=empty, h=hand" + 
    "Use upper case for white pieces and lower case for black")

for i, img in enumerate(square_images):
    cv2.imshow("Label this piece", img)
    key = cv2.waitKey(0) & 0xFF
    cv2.destroyAllWindows()

    if key == 27:  # ESC to quit
        break

    key_map = {
        ord('p'): 'bp',
        ord('n'): 'bn',
        ord('b'): 'bb',
        ord('r'): 'br',
        ord('q'): 'bq',
        ord('k'): 'bk',
        ord('e'): 'e',
        ord('P'): 'wp',
        ord('N'): 'wn',
        ord('B'): 'wb',
        ord('R'): 'wr',
        ord('Q'): 'wq',
        ord('K'): 'wk',
        ord('h'): 'h'
    }

    label = key_map.get(key)
    if label:
        # Generate a unique filename (e.g. continue from existing count)
        existing_files = os.listdir(output_dir)
        next_index = len(existing_files)

        filename = f"{next_index}_{label}.png"
        filepath = os.path.join(output_dir, filename)
        cv2.imwrite(filepath, img)
        print(filepath)
        labels[filename] = label
    else:
        print("Invalid key, skipping this image.")

# Save labels as pickle for future use
with open("piece_labels.pkl", "wb") as f:
    pickle.dump(labels, f)

print("Labeling complete. Dataset saved.")